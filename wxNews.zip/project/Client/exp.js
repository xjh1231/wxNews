

// npm install express --save
// npm install ejs --save

var fs = require('fs');
var express = require("express");
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.json());

//get请求滑动新闻页
app.get('/api/banners',function (req,res) {
	console.log(req.query);
	console.log(req.body);
	fs.readFile('banners.json', 'utf-8', function (err, data) {
		if (err) {
			console.log(err);
		} else {
			res.writeHead(200,{'Content-Type':'application/json;charset=utf-8'});
			//res.end(data);
			res.end(data);
		}
	});
});

//get请求新闻种类列表
app.get('/api/category/list',function (req,res) {
	console.log(req.query);
	console.log(req.body);
	fs.readFile('category-list.json', 'utf-8', function (err, data) {
		if (err) {
			console.log(err);
		} else {
			res.writeHead(200,{'Content-Type':'application/json;charset=utf-8'});
			//res.end(data);
			res.end(data);
		}
	});
});

//get请求新闻列表
app.get('/api/news/list',function (req,res) {
	console.log(req.query);

	fs.readFile('news-list.json', 'utf-8', function (err, data) {
		if (err) {
			console.log(err);
		} else {
			const value = req.query.id;
			const json_list = JSON.parse(data);
			var res_data = {
				"code": 0,
				"message": "请求成功",
				"data": []
			};
			console.log("value:"+value);
			for (var i = 0;i<Object.keys(json_list.data).length;i++){
				//console.log("listId:"+json_list.data[i].listId);
				if (JSON.stringify(json_list.data[i].listId) === req.query.id){
					//console.log("success")
					res_data.data =  res_data.data.concat(json_list.data[i]);
					//console.log(json_list.data[i]);
					//console.log(res_data);
				}
				//console.log(1);
			}

			data = JSON.stringify(res_data);
			res.writeHead(200,{'Content-Type':'application/json;charset=utf-8'});
			res.end(data);
		}
	});
});





//get请求新闻内容
app.get("/api/news/detail",function(req,res){
	fs.readFile('news-detail.json', 'utf-8', function (err, data) {
		if (err) {
			console.log(err);
		} else {
			res.writeHead(200,{'Content-Type':'application/json;charset=utf-8'});
			res.end(data);
		}
	});
});

app.get("/api/news/comment",function(req,res){

	fs.readFile('comment.json', 'utf-8', function (err, data) {
		if (err) {
			console.log(err);
		} else {
			const detail_id = req.query.detail_id;
			const json_comment = JSON.parse(data);
			var res_data = {
				"code": 0,
				"message": "请求成功",
				"data": []
			};
			console.log("detail_id:"+detail_id);
			for (var i = 0;i<Object.keys(json_comment.data).length;i++){
				//console.log("listId:"+json_list.data[i].listId);
				if (JSON.stringify(json_comment.data[i].detail_id) === req.query.detail_id){
					//console.log("success")
					res_data.data =  res_data.data.concat(json_comment.data[i]);
					//console.log(json_list.data[i]);
					//console.log(res_data);
				}
				//console.log(1);
			}

			data = JSON.stringify(res_data);
			res.writeHead(200,{'Content-Type':'application/json;charset=utf-8'});
			res.end(data); // 表示未取餐
		}
	});
});

app.get("/api/news/like",function(req,res){
	fs.readFile('like.json', 'utf-8', function (err, data) {
		console.log(data)
		if (err) {
			console.log(err);
		} else {
			res.writeHead(200,{'Content-Type':'application/json;charset=utf-8'});
			res.end(data); // 表示未取餐
		}
	});
});

app.post("/api/addlike",function(req,res){
	console.log(req.body)
	fs.readFile('news-detail.json', 'utf-8', function (err, data) {
		if (err) {
			console.log(err);
		} else {
			const json_1 = JSON.parse(data);
			const i = req.body.id - 1;
			json_1.data[i].like = - json_1.data[i].like;
			console.log(json_1.data[i].like)
			fs.readFile('like.json', 'utf-8', function (err, data) {
				if(err){
					console.log(err);
				}else {
					const json_like = JSON.parse(data);
					//todo read index true/false{
					fs.readFile('news-list.json', 'utf-8', function (err, data) {
						if(err){
							console.log(err);
						}else {
							const json_news = JSON.parse(data);
							const j = req.body.id - 1;
							const json_oneNews = json_news.data[j];
							console.log(json_oneNews)
							if(json_1.data[i].like === 1){
								//如果收藏
								//todo true
								json_news.data[j].likeurl = true;

								const newjsonlike = json_like.data.concat(json_oneNews)
								const liketotle = {
									"code": 0,
									"message": "请求成功",
									"data": newjsonlike
								}
								console.log(newjsonlike)
								fs.writeFile('like.json', JSON.stringify(liketotle, undefined, 4), 'utf-8', (err) => {
									if (err) {
										console.error('Error writing to file:', err);
									} else {
										console.log('like文件写入成功');
									}
								});


							}else if(json_1.data[i].like === -1){
								//todo false
								json_news.data[j].likeurl = false;
								const propertyToDelete = 'id'; // 要删除的项的属性名
								const valueToDelete = json_1.data[i].id; // 要删除的项的属性值

								const indexToDelete = json_like.data.findIndex(item => item[propertyToDelete] === valueToDelete);
								if (indexToDelete !== -1) {
									json_like.data.splice(indexToDelete, 1);
								}
								fs.writeFile('like.json', JSON.stringify(json_like, undefined, 4), 'utf-8', (err) => {
									if (err) {
										console.error('Error writing to file:', err);
									} else {
										console.log('detail文件删除数据成功');
									}
								});
							}
							fs.writeFile('news-list.json', JSON.stringify(json_news, undefined, 4), 'utf-8', (err) => {
								if (err) {
									console.error('Error writing to file:', err);

								} else {
									console.log('文件写入成功');

								}
							})
						}
					});

					//}
					//todo write
				}
			})

			fs.writeFile('news-detail.json', JSON.stringify(json_1, undefined, 4), 'utf-8', (err) => {
				if (err) {
					console.error('Error writing to file:', err);
					res.json({ error: 1, message: '写入文件出错' });
				} else {
					console.log('文件写入成功');
					res.json({ error: 0 });
				}
			});
		}
	});

});

app.post("/api/news/loadcomment", function (req, res) {
	console.log(req.body.detail_id);

	fs.readFile('comment.json', 'utf-8', function (err, data) {
		if (err) {
			console.log(err)
		} else {
			var json_comment = JSON.parse(data);
			var currentDate = new Date();

			var one_comment = {
				"id": Object.keys(json_comment.data).length + 1,
				"detail_id": req.body.detail_id,
				"url": "../../../image/portrait/3.jpg",
				"user": "iKun_" + (Object.keys(json_comment.data).length + 1),
				"city": "北京",
				"time": formatTime(currentDate),
				"comment": req.body.comment,
			};

			json_data = json_comment.data.concat(one_comment);
			json_comment = {
				"code": 0,
				"message": "请求成功",
				"data": json_data,
			}
			fs.writeFile('comment.json', JSON.stringify(json_comment, undefined, 4), 'utf-8', (err) => {
				if (err) {
					console.error('Error writing to file:', err);
					res.json({ error: 1, message: '写入文件出错' });
				} else {
					console.log('文件写入成功');
					res.json({ error: 0 });
				}
			});
		}
	})
});

function formatTime(date) {
	var year = date.getFullYear();
	var month = formatTwoDigits(date.getMonth() + 1);
	var day = formatTwoDigits(date.getDate());
	var hours = formatTwoDigits(date.getHours());
	var minutes = formatTwoDigits(date.getMinutes());

	return year + "-" + month + "-" + day + " " + hours + ":" + minutes;
}

function formatTwoDigits(number) {
	return number < 10 ? "0" + number : number;
}


app.listen(8081);    

