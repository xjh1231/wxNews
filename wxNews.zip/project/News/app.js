//app.js
App({
  data:{
    flag:false
  },
  onload(){
    
  }
})