const fetch=require('../../../utils/fetch.js')


Page({
    data:{
        article:{},
        id:0,
        comment:[],
        tagStyle: {
            img: "display: block; width: 100%; height: auto;",
            h2: "margin: 10px 0",
        },
        relations: [],
        islike:'',
        content:'',//文本类容
        bottomHeight:0 //定义comment容器与page容器下边界之间的距离
    },
    onLoad:function({ id }){
        this.refreshArticle(id)
        //this.refreshRelationArticles()
        this.getcomment(id)
        this.setData({
          id:id
        })
    },
    refreshArticle (id) {
      fetch('news/detail').then((res)=>{
        wx.hideLoading();
        this.setData({
          article:res.data.data[id-1]
        })
        console.log(this.data.article)
        if(this.data.article.like == -1){
          this.setData({
            islike:false
          })
        }
        else if(this.data.article.like == 1){
          //console.log('success')
          this.setData({
            islike:true
          })
        }
      })
    },
    refreshRelationArticles () {
      fetch('news/list').then((res)=>{
        const relations=res.data.data.sort((a, b) => 0.5 - Math.random())
        this.setData({ 
          relations :relations
        })
      })
    },
    getcomment(id){
      fetch('news/comment',{detail_id:id}).then((res)=>{
        const comment = res.data.data
        this.setData({
          comment :comment
        })
      })
    },
    addlike(e){
      var id = e.currentTarget.dataset.id;
      var method = 'POST'
      let islike = !this.data.islike
      //console.log(id)
      fetch('addlike',{id:id},method).then((res)=>{
        //wx.hideLoading();
        //console.log(res)
        // wx.switchTab({
        //   url: '../index',
        // })
      })
      this.setData({
        islike:islike
      })
      if(islike){
        wx.showToast({
          title: '收藏成功',
          duration:1000,
          icon:"success",
          mask:true
        })
      }
      if(!islike){
        wx.showToast({
          title: '取消收藏',
          duration:1000,
          icon:"error",
          mask:true
        })
      }
    },

  // 获取焦点 唤起软键盘
  bindfocus(e){
    console.log(e, '键盘弹起')
    console.log(e)
    this.setData({
      bottomHeight:e.detail.height //将键盘的高度设置为comment容器与page容器下边界之间的距离。
    })
   
    },
    // 输入内容
    bindinput(e){
      this.setData({
        content:e.detail.value
      })
    },
    // 失去焦点 
    bindblur(e){
      console.log(e, '收起键盘')
      this.setData({
        bottomHeight:0
      })
    },
    //
    sendOut(e){
      var id = e.currentTarget.dataset.id;
      var method = 'POST';
      var nickname = '';
      let content=this.data.content //使用解构 
      // wx.getUserProfile({
      //   success: ({ userInfo }) => {
      //     userInfo: { nickname: userInfo.nickName };
      //   },
      //   fail: () => wx.showToast({ title: '获取失败', icon: 'error' })
      // })
      // console.log(nickname)
      //调用发送接口
      fetch('news/loadcomment',{detail_id:id,comment:content},method).then((res) =>{
        this.getcomment(id);
        wx.showToast({
          title: '评论成功',icon:'success'
        })
        this.setData({
          content:''
        })

      })
      
    },

})