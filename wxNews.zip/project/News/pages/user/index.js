Page({
  data:{
    userInfo: {
      nickname: '',
      avatar: ''
    },
    islogin:false,
    isshow:true
  },
  onLoad(){
    wx.hideTabBar()
  },
  doGetUserData () {
    wx.getUserProfile({
      desc: '申请获取你的个人资料',
      success: ({ userInfo }) => {
        this.setData({
          userInfo: { nickname: userInfo.nickName, avatar: userInfo.avatarUrl },
          islogin:true
        })
      },
      fail: () => wx.showToast({ title: '获取失败', icon: 'error' })
    })
  },
  toindex(){
    wx.switchTab({
      url: '../news/index',
    })
    wx.showTabBar();
    this.setData({
      isshow:false
    })
  }
})