// pages/like/like.js
const fetch=require('../../utils/fetch.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
      like:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getlike()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  getlike () {
    fetch('news/like').then((res)=>{
      wx.hideLoading();
      console.log(res.data.data)
      this.setData({
        like:res.data.data
      })
    })
  },

  onShow: function(){
        const pages = getCurrentPages()
        const perpage = pages[pages.length - 1]
        perpage.onLoad()  
      }
})